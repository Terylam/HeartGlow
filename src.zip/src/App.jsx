import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Home";
import Chatroom from "./Chatroom";
import Health from "./Health";
import Info from "./Info";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/" element={<Home />} />
        <Route path="/chatroom" element={<Chatroom />} />
        <Route path="/health" element={<Health />} />
        <Route path="/info" element={<Info />} />
      </Routes>
    </Router>
  );
}

export default App;
