import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation, Link } from "react-router-dom";
import { ArrowUpToLine, ArrowDownFromLine, Eraser, HelpCircle } from 'lucide-react';
import './App.css';
import background from './assets/pic1.jpeg';
import guidePdf from './assets/heartglow_guide.pdf';

// Known music filename to label mappings
const musicNameMap = {
  'ocean': 'Ocean Waves',
  'forest': 'Forest Sounds',
  'coffee': 'Coffee Shop Ambience',
  'white': 'White Noise',
};

// Helper function to convert filename to display label
const getMusicLabel = (filename) => {
  // Check if there's a known mapping first
  if (musicNameMap[filename]) {
    return musicNameMap[filename];
  }
  
  // Remove file extension
  const nameWithoutExt = filename.replace(/\.(mp3|wav|ogg|m4a)$/i, '');
  
  // Check for known name without extension
  if (musicNameMap[nameWithoutExt]) {
    return musicNameMap[nameWithoutExt];
  }
  
  // Remove UUID prefix if present (e.g., "990efc76-fc34-4703-8877-1e135b0888dd_")
  const nameWithoutUuid = nameWithoutExt.replace(/^[a-f0-9-]+_/i, '');
  
  // Replace underscores with spaces and capitalize words
  const label = nameWithoutUuid.replace(/_/g, ' ');
  
  return label;
};

// Available music options (placeholders for local files)
const musicOptions = [
  { label: 'Choose Music Here', value: '' },
  { label: 'None (No Music)', value: '' },
  { label: 'Relaxing Rain', value: './custom_song_2.mp3' },
  { label: 'Ocean Waves', value: 'ocean' },
  { label: 'Forest Sounds', value: 'forest' },
  { label: 'Coffee Shop Ambience', value: 'coffee' },
  { label: 'White Noise', value: 'white' },
];

// Backend API URL configuration - update this to match your backend server
const BACKEND_WS_URL = import.meta.env.VITE_BACKEND_WS_URL || `ws://${window.location.hostname}:8000`;
const BACKEND_HTTP_URL = import.meta.env.VITE_BACKEND_HTTP_URL || `http://${window.location.hostname}:8000`;

// ✅ Also update formatTimestamp to match
const formatTimestamp = () => {
  const now = new Date();
  // Extract components in Asia/Hong_Kong timezone (HKT), 24-hour format
  const year = now.toLocaleString('en-US', { year: 'numeric', timeZone: 'Asia/Hong_Kong' });
  const month = now.toLocaleString('en-US', { month: '2-digit', timeZone: 'Asia/Hong_Kong' });
  const day = now.toLocaleString('en-US', { day: '2-digit', timeZone: 'Asia/Hong_Kong' });
  const hour = now.toLocaleString('en-US', { hour: '2-digit', hour12: false, timeZone: 'Asia/Hong_Kong' });
  const minute = now.toLocaleString('en-US', { minute: '2-digit', timeZone: 'Asia/Hong_Kong' });

  return `${year}-${month}-${day} ${hour}:${minute}`;
};

// Helper function to parse markdown and return formatted React elements
// **text** for bold, *text* for italic
const parseMarkdown = (text) => {
  if (!text) return null;
  
  // Split by ** for bold, then further split by * for italic
  // Using regex to find markdown patterns
  const parts = text.split(/(\*\*.*?\*\*|\*.*?\*)/g);
  
  return parts.map((part, index) => {
    if (!part) return null;
    
    // Check for bold (**text**)
    if (part.startsWith('**') && part.endsWith('**') && part.length > 2) {
      return <strong key={index} style={{ fontWeight: 'bold' }}>{part.slice(2, -2)}</strong>;
    }
    // Check for italic (*text*)
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return <em key={index} style={{ fontStyle: 'italic' }}>{part.slice(1, -1)}</em>;
    }
    // Regular text
    return <span key={index}>{part}</span>;
  });
};

// Helper function to extract timestamp from message
// Now extracts time from the backend's time field in the payload
// ✅ Updated extractTimestamp
// NO fallback to current time — only returns backend time or placeholder "—"
const extractTimestamp = (data) => {
  if (!data) {
    return "—";
  }
  // Try both 'time' and 'timestamp' field names
  const ts = data.time || data.timestamp;
  if (!ts || typeof ts !== 'string') {
    return "";
  }
  return ts; // e.g., "2024-06-05 17:15"
};




function Chatroom() {
  const location = useLocation();
  const [username, setUsername] = useState(() => location.state?.username ?? '');
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    isMobile: window.innerWidth < 768,
  });

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [selectedMusic, setSelectedMusic] = useState('');
  const [musicVolume, setMusicVolume] = useState(0.5);
  const [isMusicPaused, setIsMusicPaused] = useState(false);
  const musicRef = useRef(null);
  const fileInputRef = useRef(null);
  // State for backend music files
  const [backendMusicFiles, setBackendMusicFiles] = useState([]);
  const [isUploadingMusic, setIsUploadingMusic] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };
  const ws = useRef(null); // Store WebSocket instance
  const messagesStartRef = useRef(null);
  const messagesEndRef = useRef(null);
  const navigate = useNavigate();
  const [isMuted] = useState(false);
  const [voiceProcessingCounter, setVoiceProcessingCounter] = useState(0); // 0 = idle, 1 = processing
  const skippingRef = useRef(true); // Start with true to skip history on reload
  const histOnRef = useRef(false);
  const usernameSentRef = useRef(false);
  const usernameRef = useRef(username);
  const [wsReady, setWsReady] = useState(false);
  const enabledRef = useRef(false); // TTS enabled state
  useEffect(() => { usernameRef.current = username; }, [username]);

  // Keep username in sync when navigating from Home with state
  useEffect(() => {
    if (location.state?.username != null) {
      setUsername(location.state.username);
    }
  }, [location.state]);

  // Send username to backend as first message once WebSocket is open (backend then sends conversation history)
  useEffect(() => {
    if (!wsReady || !username?.trim() || usernameSentRef.current) return;
    if (ws.current?.readyState === WebSocket.OPEN) {
      const nameToSend = username.trim().replace(/\s+/g, '_');
      ws.current.send(nameToSend);
      usernameSentRef.current = true;
    }
  }, [username, wsReady]);
  
  
  useEffect(() => {
    const applyMute = () => {
      document.querySelectorAll("audio, video").forEach(el => {
        el.muted = isMuted;
      });
    };

    // Run once initially
    applyMute();

    // Watch for new nodes being added
    const observer = new MutationObserver(() => {
      applyMute();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    return () => observer.disconnect();
  }, [isMuted]);

  
  // Initialize WebSocket connection
  useEffect(() => {
    // Create WebSocket connection using configured backend URL
    console.log('Connecting to WebSocket:', `${BACKEND_WS_URL}/chat`);
    ws.current = new WebSocket(`${BACKEND_WS_URL}/chat`);
    ws.current.onopen = () => {
      setWsReady(true);
      const name = usernameRef.current?.trim();
      if (name && !usernameSentRef.current) {
        // Start loading popup before sending username to request history
        setIsLoadingHistory(true);
        // Show loading status after login
        setIsLoadingStatus(true);
        ws.current.send(name.replace(/\s+/g, '_'));
        usernameSentRef.current = true;
      }
    };
    ws.current.onclose = () => setWsReady(false);

        ws.current.onmessage = async (event) => {
      try {
        const data = JSON.parse(event.data);
        
        let botReply = data.text;
        console.log("Received message:", botReply);
        
        // Handle bot message type from backend - extract timestamp for all message types
        let botTime = null;
        if (data.type === "message") {
          // Bot has finished responding, stop loading status
          setIsLoadingStatus(false);
          // Use the time from backend payload if available
          botTime = extractTimestamp(data) || "—";
          console.log("Received bot message:", botReply, "Time:", botTime);
        }
        
        // === History skipping logic ===
        if (botReply.includes("Sending conversation history")) {
          console.log("Starting history loading");
          skippingRef.current = true;
          histOnRef.current = true;
          setIsLoadingHistory(true);
          // Send audio_off message to backend only during history loading
          if (ws.current && ws.current.readyState === WebSocket.OPEN) {
            //ws.current.send("audio_off");
            console.log("Sent audio_off to backend");
          }
        }
        if (botReply.includes("End of history")) {
          console.log("Ending history loading");
          skippingRef.current = false;
          histOnRef.current = false;
          setIsLoadingHistory(false);
          setIsLoadingStatus(false);
          // Send audio_on message to backend only during history loading
          //if (ws.current && ws.current.readyState === WebSocket.OPEN) {
          //  ws.current.send("audio_on");
          //  console.log("Sent audio_on to backend");
          //}
          return; // don't show or speak the "End of history" line
        }
        
        // === Show message in chat ===
        if (botReply.trim() !== "") {
          console.log("Processing message, histOnRef.current:", histOnRef.current);
          if (histOnRef.current) {
            console.log("Adding historical message:", botReply);
            setChatHistory(prev => [
              ...prev,
              botReply.toLowerCase().startsWith("bot:")
                ? { bot: botReply.replace(/^bot:\s*/i, ""), timestamp: botTime || "—" } // use backend time if available
                : { user: botReply, timestamp: botTime || formatTimestamp() }
            ]);
          } else {
            console.log("Adding new message:", botReply);
            setChatHistory(prev => [
              ...prev,
              { bot: botReply.replace(/^bot:\s*/i, ""), timestamp: botTime || formatTimestamp() } // use backend time if available
            ]);
            // Force scroll to bottom
            scrollToBottom();
            // Hide loading status when bot response is
          }
        }
        
        // === Stop any previous audio immediately ===
        if (ws.current._audio) {
          ws.current._audio.pause();
          ws.current._audio.currentTime = 0;
        }

    
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    };
    
    

    ws.current.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    ws.current.onclose = () => {
      console.log('WebSocket closed');
    };

/*
    // Cleanup on component unmount
    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };*/
    // Auto-scroll to bottom whenever chatHistory changes
  },[]);

  // Function to voice the latest bot message
  const voiceLatestBotMessage = async () => {
    // Prevent duplicate voice requests while processing
    if (voiceProcessingCounter === 1) {
      console.log("Voice already processing, skipping duplicate request");
      return;
    }
    
    // Set to processing state
    setVoiceProcessingCounter(1);
    
    console.log("Voicing latest bot message");
    
    // Find the latest bot message from chat history
    const latestBotMessage = chatHistory
      .filter(msg => msg.bot)
      .pop();
    
    if (latestBotMessage && latestBotMessage.bot) {
      console.log("Voicing bot message:", latestBotMessage.bot);
      
      try {
        const response = await fetch(`${BACKEND_HTTP_URL}/tts/`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: latestBotMessage.bot }),
        });

        if (!response.ok) throw new Error("TTS failed");

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);

        const audio = new Audio(url);
        audio.play();
        
        // Reset counter after audio starts
        audio.onended = () => {
          setVoiceProcessingCounter(0);
        };
        audio.onerror = () => {
          setVoiceProcessingCounter(0);
        };
        
      } catch (error) {
        console.error("TTS error:", error);
        setVoiceProcessingCounter(0);
      }
    } else {
      console.log("No bot message found to voice");
      setVoiceProcessingCounter(0);
    }
  };
/*
  useEffect(() => {
    const handleKeyDown = async (e) => {
      const key = e.key.toLowerCase();

      // Ctrl + A → voice the latest bot message
      if ((key === "a") && e.ctrlKey) {
        console.log("Ctrl+A pressed - voicing latest bot message");
        voiceLatestBotMessage();
        return;
      }

      // Ctrl + O → turn OFF TTS
      if ((key === "o") && e.ctrlKey) {
        enabledRef.current = false;
        console.log("TTS OFF");
        return;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [chatHistory]);*/

  useEffect(() => {
    const handleResize = () => {
      setWindowSize(prev => ({
        ...prev,
        width: window.innerWidth,
        isMobile: window.innerWidth < 768,
      }));
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Fetch music list from backend on component mount
  useEffect(() => {
    const fetchMusicList = async () => {
      try {
        const response = await fetch(`${BACKEND_HTTP_URL}/music/list`);
        if (response.ok) {
          const data = await response.json();
          if (data.music_files) {
            setBackendMusicFiles(data.music_files);
            console.log('Music files loaded from backend:', data.music_files);
          }
        }
      } catch (error) {
        console.error('Failed to fetch music list:', error);
      }
    };
    fetchMusicList();
  }, []);

  // Upload music file to backend
  const uploadMusicToBackend = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    
    setIsUploadingMusic(true);
    try {
      const response = await fetch(`${BACKEND_HTTP_URL}/music/upload`, {
        method: 'POST',
        body: formData,
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('Music uploaded successfully:', data);
        // Refresh music list
        const listResponse = await fetch(`${BACKEND_HTTP_URL}/music/list`);
        if (listResponse.ok) {
          const listData = await listResponse.json();
          if (listData.music_files) {
            setBackendMusicFiles(listData.music_files);
          }
        }
        return { success: true, filename: data.filename, originalName: data.original_name };
      } else {
        const errorData = await response.json();
        return { success: false, error: errorData.error || 'Upload failed' };
      }
    } catch (error) {
      console.error('Upload error:', error);
      return { success: false, error: error.message };
    } finally {
      setIsUploadingMusic(false);
    }
  };

  // Music playback functions
  const playMusic = (musicType) => {
    setIsMusicPaused(false);
    if (musicType && musicType.startsWith('/music/')) {
      // Backend music - use backend URL
      const fullUrl = `${BACKEND_HTTP_URL}${musicType}`;
      if (musicRef.current) {
        musicRef.current.src = fullUrl;
        musicRef.current.load();
        musicRef.current.play().catch(error => {
          console.log('Playback failed:', error);
        });
      }
    } else if (musicRef.current) {
      musicRef.current.play().catch(error => {
        console.log('Playback failed:', error);
      });
    }
  };

  const stopMusic = () => {
    setIsMusicPaused(false);
    if (musicRef.current) {
      musicRef.current.pause();
      musicRef.current.currentTime = 0;
    }
  };

  const toggleMusicPause = () => {
    if (musicRef.current) {
      if (isMusicPaused) {
        musicRef.current.play();
        setIsMusicPaused(false);
      } else {
        musicRef.current.pause();
        setIsMusicPaused(true);
      }
    }
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Upload to backend first
      uploadMusicToBackend(file).then(result => {
        if (result.success) {
          // Set the src to the backend music URL
          const musicPath = `/music/${result.filename}`;
          if (musicRef.current) {
            musicRef.current.src = `${BACKEND_HTTP_URL}${musicPath}`;
            musicRef.current.load();
            setSelectedMusic(result.originalName);
            playMusic(musicPath);
          }
        } else {
          alert(`Upload failed: ${result.error}`);
        }
      });
    }
  };

  const scrollToTop = () => {
    messagesStartRef.current?.scrollIntoView({ behavior: 'smooth' , block: 'start'});
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  };

  const clearPage = () => {
    navigate("/chatroom"); // navigates to chatroom route
    setChatHistory([]);
    setChatHistory(prev => [...prev, { bot: "Please feel free to ask me more!", timestamp: formatTimestamp() }]);
  };

  useEffect(() => {
    if(chatHistory.length === 0){
    setChatHistory([]);
    setChatHistory(prev => [...prev, { bot: "Welcome! I'm really glad you're here. Please wait patiently before I'm ready to serve you!", timestamp: formatTimestamp() }]);}
  }, [chatHistory]); // empty array → runs only once when the app starts

  const sendMessage = () => {
    const trimmed = (message ?? "").trim();   // null‑safe trim
    if (!trimmed) return;                     // skip empty input
    // Add user message to chat history with timestamp
    setChatHistory([...chatHistory, { user: message, timestamp: formatTimestamp() }]);

    // Show loading status after sending message
    setIsLoadingStatus(true);

    // Send message via WebSocket
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      //ws.current.send(JSON.stringify({ message }));
        ws.current.send(message);
    } else {
      console.error('WebSocket is not connected');
      setChatHistory((prev) => [...prev, { bot: 'Error: WebSocket not connected' }]);
      // Hide loading status if WebSocket is not connected
      setIsLoadingStatus(false);
    }

    setMessage('');
  };

  const handleKeyPress = (e) => {
    // Handle Enter key
    if (e.key === 'Enter') {
      e.preventDefault(); // Prevent form submission
      sendMessage();
      scrollToBottom();
      setVoiceProcessingCounter(0);
    }
  }

 

  return (
    <>
    <div className={`app-container ${isFullscreen ? 'fullscreen' : ''}`} style={{ 
      '--background-url': `url(${background})`,
      maxWidth: windowSize.isMobile ? '95%' : '800px',
      margin: '0 auto'
    }}>
      {/* Hidden audio element for music playback */}
      <audio
        ref={musicRef}
        className="music-player"
        loop={true}
        volume={musicVolume}
        onEnded={() => {
          // Auto-select next music option (if using placeholder music)
          // For now, just stop playback
        }}
      />
      
      <header className="chat-header">
        <div className="header-content">
          <div className="header-avatar">💜</div>
          <div className="header-info">
            <h2>HeartGlow</h2>
            <span className="header-status">Your Personal Support</span>
          </div>
          <div className="header-music">
            <label className="music-switch-label" htmlFor="music-select">
              🎵 Music
            </label>
            <select
              id="music-select"
              className="music-select"
              value={selectedMusic}
              onChange={(e) => {
                setSelectedMusic(e.target.value);
                if (e.target.value) {
                  playMusic(e.target.value);
                } else {
                  stopMusic();
                }
              }}
            >
              {/* Frontend placeholder options */}
              {musicOptions.map((option) => (
                <option key={`frontend-${option.value}`} value={option.value}>
                  {option.label}
                </option>
              ))}
              {/* Backend uploaded music files */}
              {backendMusicFiles.map((file) => {
                // Use getMusicLabel function to convert filename to display label
                const displayLabel = getMusicLabel(file.filename);
                return (
                  <option key={`backend-${file.filename}`} value={file.path}>
                    {displayLabel}
                  </option>
                );
              })}
            </select>
            {/* File input for local music selection */}
            <input
              type="file"
              accept="audio/*"
              ref={fileInputRef}
              onChange={handleFileSelect}
              style={{ display: 'none' }}
            />
            <button
              className="music-toggle-btn"
              onClick={() => {
                if (selectedMusic) {
                  toggleMusicPause();
                }
              }}
              disabled={!selectedMusic}
              title={isMusicPaused ? "Resume Music" : "Pause Music"}
            >
              {isMusicPaused ? '▶' : '⏸'}
            </button>
            <button
              className="music-file-btn"
              onClick={() => fileInputRef.current?.click()}
              title="Select music from local"
            >
              📂
            </button>
          </div>
        </div>
      </header>
      <div className="chat-history">
      <div ref={messagesStartRef} />
        {chatHistory.map((msg, i) => (
          <div key={i} className={`message-wrapper ${msg.user ? 'user-wrapper' : 'bot-wrapper'}`}>
            <div className={msg.user ? 'user-msg' : 'bot-msg'}>
              <span className="message-text">{parseMarkdown(msg.user || msg.bot)}</span>
              <span className="message-timestamp">{msg.timestamp}</span>
            </div>
          </div>
        ))}
      
        <div ref={messagesEndRef} />
      </div>

      {/* Loading Status Indicator */}
      {isLoadingStatus && (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '12px',
          backgroundColor: '#4f46e5',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          borderRadius: '12px',
          minWidth: '80px',
          margin: '8px 0',
          width: '100%',
          boxSizing: 'border-box',
        }}>
          <div style={{
            width: '20px',
            height: '20px',
            border: '2px solid rgba(255, 255, 255, 0.3)',
            borderTop: '2px solid #4f46e5',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            marginBottom: '6px',
          }}></div>
          <span style={{
            color: 'rgba(255, 255, 255, 0.8)',
            fontSize: '12px',
            textAlign: 'center',
          }}>
            Processing...
          </span>
          <style>{`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      )}
      
      <div className="input-container">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Type a message..."
        />
        <button onClick={sendMessage}>Send</button>
        <button onClick={voiceLatestBotMessage} disabled={voiceProcessingCounter === 1}>
          {voiceProcessingCounter === 1 ? "Processing..." : "Read Message"}
        </button>
      </div>
      <footer>
        <div className="footer-content">
          <div className="footer-links">
            <Link 
              to="/home" 
              className="footer-btn footer-btn-primary"
              onClick={() => {
                if (ws.current) {
                  ws.current.close();
                  ws.current = null;
                }
                setUsername('');
                setChatHistory([]);
              }}
            >
              ← Back to Home
            </Link>
            <Link to="/info" target="_blank" rel="noopener noreferrer" className="footer-btn">
              ℹ Useful Info
            </Link>
          </div>
          <div className="footer-actions">
            
            <button onClick={scrollToTop} className="footer-icon-btn" title="Scroll to top">&#10514;</button>
            <button onClick={scrollToBottom} className="footer-icon-btn" title="Scroll to bottom">&#x2913;</button>
            <button onClick={clearPage} className="footer-icon-btn" title="Clear chat" >Clear</button>
            
            <button
              className="footer-icon-btn"
              onClick={() => {
                const newWindow = window.open(guidePdf, "_blank");
              }}
              title="Help"
            >
              📜
            </button>
          </div>
        </div>
      </footer>
    </div>
    </>
  );
}

export default Chatroom;