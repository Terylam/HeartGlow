import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "lucide-react";
import guidePdf from './assets/heartglow_guide.pdf';

const Home = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [userExists, setUserExists] = useState(null);
  const [checkingUser, setCheckingUser] = useState(false);

  const handleInitialize = async () => {
    if (username.trim()) {
      setCheckingUser(true);
      try {
        // Replace with your actual ngrok URL for online access
        const ngrokUrl = "https://your-ngrok-url.ngrok-free.app";
        const response = await fetch(`${ngrokUrl}/check-user/${encodeURIComponent(username.trim())}`);
        const data = await response.json();
        setUserExists(data.exists);
        setShowConfirmation(true);
      } catch (error) {
        console.error("Error checking user:", error);
        setUserExists(false);
        setShowConfirmation(true);
      } finally {
        setCheckingUser(false);
      }
    }
  };

  const handleConfirm = () => {
    setShowConfirmation(false);
    navigate("/chatroom", { state: { username } });
  };

  const handleCancel = () => {
    setShowConfirmation(false);
  };

  const styles = {
    container: {
      minHeight: "100vh",
      width: "100vw",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "16px",
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      color: "white",
      position: "relative",
      overflow: "hidden",
      backgroundColor: "#1f1b5e",
    },
    backgroundBlobs: {
      position: "fixed",
      inset: "0",
      zIndex: -10,
      overflow: "hidden",
    },
    blob: {
      position: "absolute",
      borderRadius: "50%",
      filter: "blur(120px)",
      opacity: "0.3",
      animation: "pulse 3s infinite",
    },
    blob1: {
      top: "-10%",
      left: "-10%",
      width: "500px",
      height: "500px",
      backgroundColor: "rgba(168, 85, 247, 0.3)",
    },
    blob2: {
      bottom: "-10%",
      right: "-10%",
      width: "500px",
      height: "500px",
      backgroundColor: "rgba(37, 99, 235, 0.3)",
      animationDelay: "0.7s",
    },
    blob3: {
      top: "30%",
      right: "20%",
      width: "300px",
      height: "300px",
      backgroundColor: "rgba(236, 72, 153, 0.2)",
      filter: "blur(100px)",
    },
    mainCard: {
      position: "relative",
      width: "320px",
      maxWidth: "450px",
    },
    topDecoration: {
      position: "absolute",
      top: "-80px",
      left: "-80px",
      width: "128px",
      height: "128px",
      backgroundColor: "rgba(255, 255, 255, 0.1)",
      backdropFilter: "blur(12px)",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      borderRadius: "24px",
      transform: "rotate(12deg)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    mainCircle: {
      width: "320px",
      maxWidth: "450px",
      aspectRatio: "1",
      backgroundColor: "rgba(255, 255, 255, 0.1)",
      backdropFilter: "blur(40px)",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      borderRadius: "50%",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      padding: "48px",
      textAlign: "center",
      boxShadow: "0 0 100px rgba(255, 255, 255, 0.05)",
    },
    topLine: {
      width: "64px",
      height: "4px",
      background: "linear-gradient(to right, transparent, white, transparent)",
      marginBottom: "32px",
    },
    title: {
      fontSize: "48px",
      fontWeight: "300",
      letterSpacing: "0.2em",
      textTransform: "uppercase",
      marginBottom: "32px",
    },
    input: {
      width: "100%",
      backgroundColor: "rgba(255, 255, 255, 0.05)",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      borderRadius: "9999px",
      padding: "12px 24px",
      textAlign: "center",
      outline: "none",
      color: "white",
      fontSize: "14px",
      fontFamily: "inherit",
      transition: "border-color 0.3s",
      boxSizing: "border-box",
    },
    inputFocus: {
      borderColor: "rgba(255, 255, 255, 0.6)",
    },
    button: {
      width: "100%",
      borderRadius: "9999px",
      padding: "12px 24px",
      fontSize: "20px",
      fontWeight: "700",
      letterSpacing: "0.1em",
      color: "rgba(255, 255, 255, 0.9)",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      backgroundColor: "rgba(255, 255, 255, 0.1)",
      cursor: "pointer",
      transition: "all 0.3s",
      boxSizing: "border-box",
    },
    buttonHover: {
      backgroundColor: "rgba(255, 255, 255, 0.1)",
      borderColor: "rgba(255, 255, 255, 0.4)",
    },
    hintText: {
      fontSize: "11px",
      color: "rgba(255, 255, 255, 0.6)",
      marginTop: "16px",
    },
    bottomDecoration: {
      position: "absolute",
      bottom: "-40px",
      right: "-40px",
      width: "96px",
      height: "96px",
      backgroundColor: "rgba(255, 255, 255, 0.05)",
      backdropFilter: "blur(8px)",
      border: "1px solid rgba(255, 255, 255, 0.1)",
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    indicator: {
      width: "12px",
      height: "12px",
      backgroundColor: "#4ade80",
      borderRadius: "50%",
      animation: "ping 2s infinite",
    },
    footerInfo: {
      position: "fixed",
      bottom: "32px",
      left: 0,
      right: 0,
      color: "rgba(255, 255, 255, 0.3)",
      fontSize: "14px",
      letterSpacing: "0.3em",
      textTransform: "uppercase",
      textAlign: "center",
      zIndex: 10,
    },
    healthLink: {
      position: "fixed",
      bottom: "16px",
      left: 0,
      right: 0,
      textAlign: "center",
      color: "rgba(255, 255, 255, 0.5)",
      fontSize: "12px",
      textDecoration: "none",
      zIndex: 5,
      pointerEvents: "auto",
    },
    modal: {
      position: "fixed",
      top: 0,
      left: 0,
      width: "100vw",
      height: "100vh",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      backdropFilter: "blur(4px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 100,
      pointerEvents: "auto",
    },
    modalContent: {
      backgroundColor: "rgba(15, 23, 42, 0.95)",
      backdropFilter: "blur(0px)",
      border: "1px solid rgba(255, 255, 255, 0.3)",
      borderRadius: "24px",
      padding: "32px",
      textAlign: "center",
      width: "90%",
      maxWidth: "400px",
      position: "relative",
      zIndex: 101,
      boxShadow: "0 4px 60px rgba(0, 0, 0, 0.8)",
    },
    modalTitle: {
      fontSize: "20px",
      fontWeight: "600",
      color: "white",
      marginBottom: "24px",
    },
    buttonGroup: {
      display: "flex",
      gap: "16px",
      justifyContent: "center",
    },
    modalButton: {
      padding: "12px 24px",
      borderRadius: "9999px",
      fontSize: "14px",
      fontWeight: "500",
      border: "1px solid",
      cursor: "pointer",
      transition: "all 0.3s",
    },
    confirmButton: {
      backgroundColor: "rgba(34, 197, 94, 0.8)",
      borderColor: "rgba(74, 222, 128, 0.9)",
      color: "#86efac",
    },
    confirmButtonHover: {
      backgroundColor: "rgba(34, 197, 94, 1.0)",
    },
    cancelButton: {
      backgroundColor: "rgba(239, 68, 68, 0.8)",
      borderColor: "rgba(248, 113, 113, 0.9)",
      color: "#fca5a5",
    },
    cancelButtonHover: {
      backgroundColor: "rgba(239, 68, 68, 1.0)",
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.backgroundBlobs}>
        <div style={{ ...styles.blob, ...styles.blob1 }} />
        <div style={{ ...styles.blob, ...styles.blob2 }} />
        <div style={{ ...styles.blob, ...styles.blob3 }} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        style={styles.mainCard}
      >
        <motion.div
          animate={{ y: [0, -20, 0] }}
          transition={{ repeat: Infinity, duration: 4 }}
          style={styles.topDecoration}
        >
          <Layout style={{ color: "rgba(255, 255, 255, 0.4)", width: 40, height: 40 }} />
        </motion.div>

        <div style={styles.mainCircle}>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div style={styles.topLine} />
            <h2 style={styles.title}>HeartGlow</h2>
          </motion.div>

          <div style={{ width: "100%" }}>
            <input
              type="text"
              placeholder="What's your name?"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={styles.input}
            />

            <button
              type="button"
              onClick={handleInitialize}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleInitialize();
                }
              }}
              style={styles.button}
            >
              Submit!
            </button>
            <a
                      onClick={() => {
                        const newWindow = window.open(guidePdf, "_blank");
                      }}
                      title="Help"
      >
        How to use?
      </a>
            <p style={styles.hintText}>Use Ctrl+A for AI voiceover</p>
          </div>
        </div>


        <motion.div
          animate={{ y: [0, 20, 0] }}
          transition={{ repeat: Infinity, duration: 5, delay: 1 }}
          style={styles.bottomDecoration}
        >
          <div style={styles.indicator} />
        </motion.div>
      </motion.div>

      <div style={styles.footerInfo}>Powered by Lam Chun Yin (Glass Engine 2.0)</div>





      {showConfirmation && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={styles.modal}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            style={styles.modalContent}
          >
            {userExists === false && (
              <p style={{ color: "#fca5a5", marginBottom: "16px", fontSize: "14px" }}>
                
              </p>
            )}
            <h3 style={styles.modalTitle}>
              Are you sure "{username.trim()}" is correct?
            </h3>
            <div style={styles.buttonGroup}>
              <button
                onClick={handleConfirm}
                style={{ ...styles.modalButton, ...styles.confirmButton }}
              >
                Yes
              </button>
              <button
                onClick={handleCancel}
                style={{ ...styles.modalButton, ...styles.cancelButton }}
              >
                No (Enter again)
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.5; }
        }
        @keyframes ping {
          75%, 100% { transform: scale(2); opacity: 0; }
        }
        input:focus {
          outline: none;
        }
      `}</style>
    </div>
  );
};

export default Home;