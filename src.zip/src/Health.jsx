import './App.css';

function Health() {
  return (
    <div className="app-container page-layout">
      <header className="health-header">
        <h2>Health Regulations</h2>
      </header>
      <div className="health-content">
        <p>
          This chatbot provides general support for work and peer pressure-related
          depression but is not a substitute for professional medical advice. If you're in
          crisis, contact a helpline like the National Suicide Prevention Lifeline
          (1-800-273-8255) or seek immediate help from a mental health professional.
        </p>
        <p>
          Disclaimer: All advice is AI-generated and should be verified. We comply with
          health privacy regulations (e.g., HIPAA where applicable).
        </p>
        <p>
          <br /><br /><br /><br />
          <br /><br /><br /><br />
          <br /><br /><br /><br />
          <br /><br />
        </p>
      </div>
      <footer>
        <p style={{ fontSize: '14px', color: '#818cf8' }}>
          To close this tab, please use your browser's close button (X) or press Ctrl+W / Cmd+W.
        </p>
      </footer>
    </div>
  );
}

export default Health;
