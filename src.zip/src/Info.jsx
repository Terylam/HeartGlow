import './App.css';

function Info() {
  return (
    <div className="app-container page-layout">
      <header className="health-header">
        <h2>Hope this helps you a bit!</h2>
      </header>
      <div className="health-content">
        <p>
          <a href="https://www.nami.org/about-mental-illness/mental-health-conditions/depression/" target="_blank" rel="noopener noreferrer">
            What is MDD?
          </a>
        </p>
        <p>
          <a href="https://samaritans.org.hk" target="_blank" rel="noopener noreferrer">
            Samaritans Hong Kong
          </a>
        </p>
        <p>
          <a href="https://www.gov.hk/en/residents/health/mental/mentalhealth.htm" target="_blank" rel="noopener noreferrer">
            Mental Help from the Government of Hong Kong
          </a>
        </p>
        <p>
          <a href="https://www.youtube.com/watch?v=LiUnFJ8P4gM&t=222s" target="_blank" rel="noopener noreferrer">
            Breathing Exercises
          </a>
        </p>
      </div>
      <footer>
        <p style={{ fontSize: '14px', color: '#818cf8' }}>
          To close this tab, please use your browser's close button (X) or press Ctrl+W / Cmd+W.
        </p>
      </footer>
    </div>
  );
}

export default Info;
